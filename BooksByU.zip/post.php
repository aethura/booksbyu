<?php
/**
 * Created by PhpStorm.
 * User: brute
 * Date: 3/29/2017
 * Time: 2:55 PM
 */

?>
<html>

<form action="" method="post">


<select name="Category">
    <option value="Computer Science">Computer Science</option>
</select>

</form>

</html>